# Project Photos & 3D Model

## Physical Prototype

The following photos show the actual Smart Helmet prototype, including the helmet enclosure, mounted camera/display hardware, and computer-vision demonstration.

![Helmet front](assets/project-photos/helmet-front.jpg)
![Helmet top](assets/project-photos/helmet-top.jpg)
![Helmet side](assets/project-photos/helmet-side.jpg)
![Helmet camera](assets/project-photos/helmet-camera.jpg)

### Computer Vision Demonstration

![Object detection display](assets/project-photos/helmet-display-detection-1.jpg)
![Object detection display](assets/project-photos/helmet-display-detection-2.jpg)

## 3D Model

### Interactive 3D Helmet Model

View and rotate the project's interactive 3D model on Sketchfab:

**[Open the Smart Helmet 3D Model](https://skfb.ly/pHLC6)**

> Note: GitHub does not natively render `.glb` 3D model files inside the normal repository file preview. The interactive Sketchfab model is therefore provided as the project’s 3D-model viewer.
